package pippin;

public interface Instruction {
	public void execute(int arg, int flags);
	
	public static int numOnes(int i){
		
		i = i - ((i >>> 1) & 0x55555555);
		i = (i & 0x33333333) + ((i >>> 2) & 0x33333333);
		return (((i + (i >>> 4)) & 0x0F0F0F0F) * 0x01010101) >>> 24;
		
		
		
		/*String aString =  Integer.toUnsignedString(x,2);
		int count = 0;
		for (int i = 0; i < aString.length(); i++){
			if (aString.charAt(i) == '1'){
				count += 1;
			}
		}
		return count;*/
		
	}
	
	public static void checkParity(int x){
		if((numOnes(x) & 1) == 1){ //odd number of 1's
			System.out.println("This instruction is corrupted. ");
			throw new ParityCheckException();
			
		}
	}
	
	
}
