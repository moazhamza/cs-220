package pippin;

public class Test {
	
	public static void main(String[] args){
		Instruction.checkParity(10); 
		Instruction.checkParity(1); //raises an exception
		Instruction.checkParity(11); //raises an exception
		 
		 
		
	}

}
