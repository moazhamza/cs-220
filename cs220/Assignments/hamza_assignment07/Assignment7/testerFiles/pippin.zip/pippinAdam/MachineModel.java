package pippin;

import java.util.Observable;

public class MachineModel extends Observable {

	public static final Instruction[] INSTRUCTIONS  = new Instruction[0x10]; //length 16
	private CPU cpu = new CPU();
	private Memory memory = new Memory();
	private boolean withGUI = false;
	private Code code = new Code();
	private boolean running = false;
	
	
	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}

	public void halt(){
		if(!withGUI){
			System.exit(0);
		}
		else{
			running = false;
		}
	}
	
	public Code getCode(){
		return this.code;
	}
	
	public int getChangedIndex(){
		return memory.getChangedIndex();
	}
	
	public void setPC(int aPC){
		cpu.pc = aPC;
	}
	public MachineModel(boolean condition){
		withGUI = condition;

		//INSTRUCTION_MAP entry for "NOP"
		INSTRUCTIONS[0] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags != 0) {
				String fString = "(" + (flags%8 > 3?"1":"0") + 
						(flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};



		//INSTRUCTION entry for LOD (load)
		INSTRUCTIONS[0x1] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				cpu.accum = memory.getData(arg);
			} else if(flags == 2) { // immediate addressing
				cpu.accum = arg;
			} else if(flags == 4) { // indirect addressing
				cpu.accum = memory.getData(memory.getData(arg));				
			} else { // here the illegal case is "11"
				String fString = "(" + (flags%8 > 3?"1":"0") 
						+ (flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};

		//INSTRUCTION entry for STO (store)
		INSTRUCTIONS[0x2] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				memory.setData(arg, cpu.accum);
			} else if(flags == 4) { // indirect addressing
				memory.setData(memory.getData(arg), cpu.accum);				
			} else { // here the illegal case is "11"
				String fString = "(" + (flags%8 > 3?"1":"0") 
						+ (flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};

		//INSTRUCTION entry for JUMP (jump)
		INSTRUCTIONS[0x3] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				cpu.pc += arg;
			} else if(flags == 2) { // immediate addressing
				cpu.pc = arg;
			} else if(flags == 4) { // indirect addressing
				cpu.pc += memory.getData(arg);				
			} else { // here the illegal case is "11"
				cpu.pc = memory.getData(arg);
			}

		};

		//INSTRUCTION entry for JMPZ (jump)
		INSTRUCTIONS[0x4] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(cpu.accum == 0) { // direct addressing
				if(flags == 0) { // direct addressing
					cpu.pc += arg;
				} else if(flags == 2) { // immediate addressing
					cpu.pc = arg;
				} else if(flags == 4) { // indirect addressing
					cpu.pc += memory.getData(arg);				
				} else { // here the illegal case is "11"
					cpu.pc = memory.getData(arg);
				}
			}
			else{
				cpu.pc++;			
			}
		};

		//INSTRUCTION entry for ADD (add)
		INSTRUCTIONS[0x5] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				cpu.accum += memory.getData(arg);
			} else if(flags == 2) { // immediate addressing
				cpu.accum += arg;
			} else if(flags == 4) { // indirect addressing
				cpu.accum += memory.getData(memory.getData(arg));				
			} else { // here the illegal case is "11"
				String fString = "(" + (flags%8 > 3?"1":"0") 
						+ (flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};


		//INSTRUCTION entry for SUB (add)
		INSTRUCTIONS[0x6] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				cpu.accum -= memory.getData(arg);
			} else if(flags == 2) { // immediate addressing
				cpu.accum -= arg;
			} else if(flags == 4) { // indirect addressing
				cpu.accum -= memory.getData(memory.getData(arg));				
			} else { // here the illegal case is "11"
				String fString = "(" + (flags%8 > 3?"1":"0") 
						+ (flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};

		//INSTRUCTION entry for MUL (add)
		INSTRUCTIONS[0x7] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				cpu.accum *= memory.getData(arg);
			} else if(flags == 2) { // immediate addressing
				cpu.accum *= arg;
			} else if(flags == 4) { // indirect addressing
				cpu.accum *= memory.getData(memory.getData(arg));				
			} else { // here the illegal case is "11"
				String fString = "(" + (flags%8 > 3?"1":"0") 
						+ (flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};

		//INSTRUCTION entry for DIV (divide)
		INSTRUCTIONS[0x8] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				if(memory.getData(arg) == 0){
					throw new DivideByZeroException();
				}
				cpu.accum /= memory.getData(arg);
				
			} else if(flags == 2) { // immediate addressing
				if(arg == 0){
					throw new DivideByZeroException();
				} 
				cpu.accum /= arg;
				
			} else if(flags == 4) { // indirect addressing
				if(memory.getData(memory.getData(arg)) == 0){
					throw new DivideByZeroException();
				} 
				cpu.accum /= memory.getData(memory.getData(arg));	
				
			} else { // here the illegal case is "11"
				String fString = "(" + (flags%8 > 3?"1":"0") 
						+ (flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};
		
		
		//INSTRUCTION entry for AND
		INSTRUCTIONS[0x9] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(flags == 0) { // direct addressing
				if(cpu.accum != 0 && memory.getData(arg) != 0){
					cpu.accum = 1;
				}else{
						cpu.accum = 0;
				}
			}else if(flags == 2) { // immediate addressing
				if(cpu.accum != 0 && arg != 0){
					cpu.accum = 1;
				}else{
					cpu.accum = 0;
				}	
							
			} else { // handling of all other cases
				String fString = "(" + (flags%8 > 3?"1":"0") 
						+ (flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};
		
		//INSTRUCTION entry for NOT
		INSTRUCTIONS[0xA] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			if(cpu.accum == 0){
				cpu.accum = 1;
			}else{
				cpu.accum = 0;
			}
			if(flags != 0) {
				String fString = "(" + (flags%8 > 3?"1":"0") + 
						(flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};
		
		//INSTRUCTION entry for CMPL(compare less than 0)
		INSTRUCTIONS[0xB] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			
			if(flags == 0){
				if(memory.getData(arg) < 0){
					cpu.accum = 1;
				}else{
					cpu.accum = 0;
				}
			}	
			else{
				String fString = "(" + (flags%8 > 3?"1":"0") + 
						(flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};
		
		//INSTRUCTION entry for CMPZ(compare to 0)
		INSTRUCTIONS[0xC] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			
			if(flags == 0){
				if(memory.getData(arg) == 0){
					cpu.accum = 1;
				}else{
					cpu.accum = 0;
				}
			}
			else {
				String fString = "(" + (flags%8 > 3?"1":"0") + 
						(flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			}
			cpu.pc++;			
		};
		
		
		//INSTRUCTION entry for FOR
		INSTRUCTIONS[0xD] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			
			
			if(flags == 0){ //direct addressing
				int N = memory.getData(arg);
				int numIterations = N % 0x1000;
				int numInstructions = N / 0x1000;
				int forInstruction = cpu.pc;
				
				if(numInstructions > 0 && numIterations > 0){
					for(int i =0; i < numIterations ; i ++){
						cpu.pc = forInstruction + 1;
						for(int j = 0; j < numInstructions; j++){
							step();
						}
					}
				}
			
			} else if (flags == 2){ //immediate addressing
				int N = arg;
				int numIterations = N % 0x1000;
				int numInstructions = N/ 0x1000;
				int forInstruction = cpu.pc;
				
				if(numIterations > 0 && numInstructions > 0){
					for(int i =0; i < numIterations ; i ++ ){
						cpu.pc = forInstruction + 1;
						for(int j = 0; j < numInstructions; j++){
							step();
						}
					}
				} 
			  }else { // handling of all other cases
					String fString = "(" + (flags%8 > 3?"1":"0") 
							+ (flags%4 > 1?"1":"0") + ")";
					throw new IllegalInstructionException(
							"Illegal flags for this instruction: " + fString);
				
			}
			
					
		};
		
		
		//INSTRUCTION entry for HALT(halt execution)
		INSTRUCTIONS[0xF] = (arg, flags) -> {
			flags = flags & 0x6; // remove parity bit that will have been verified
			
			if(flags != 0) {
				String fString = "(" + (flags%8 > 3?"1":"0") + 
						(flags%4 > 1?"1":"0") + ")";
				throw new IllegalInstructionException(
						"Illegal flags for this instruction: " + fString);
			} else{
				halt();
			}
			cpu.pc++;			
		};
		
	
	
	
	}
	
	public MachineModel(){
		this(false);
	}
	
	public void setCode(int op, int arg){
		code.setCode(op, arg);
	}
	
	public int getData(int i){
		return memory.getData(i);
	}
	
	public void clear(){
		memory.clear();
		code.clear();
		cpu.accum = 0;
		cpu.pc = 0;
	}
	
	public void step(){
		try{
			 int opPart = code.getOpPart(cpu.pc);
			 int arg = code.getArg(cpu.pc);
			 Instruction.checkParity(opPart);
			 INSTRUCTIONS[opPart/8].execute(arg, opPart%8);
			 
		} catch (Exception e) {
			halt();
			throw e;
		} 
	}
	

	public void setData(int i, int j) {
		memory.setData(i, j);		
	}
	public Instruction get(int i) {
		return INSTRUCTIONS[i];
	}
	int[] getData() {
		return memory.getData();
	}
	public int getPC() {
		return cpu.pc;
	}
	public int getAccum() {
		return cpu.accum;
	}
	public void setAccum(int i) {
		cpu.accum = i;
	}	

	private class CPU{
		private int accum;
		private int pc;
	}
}
