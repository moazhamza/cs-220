package pippin;

public class CodeAccessException extends RuntimeException {
	public CodeAccessException(){
		super();
	}
	
	public CodeAccessException(String message){
		super(message);
	}

}
